package com.ensox.dynamicconfig;

import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.function.Function;
import java.util.function.UnaryOperator;

/** Stores stable built-in values separately from replaceable runtime values. */
public final class ExtensibleValueRegistry<T extends ExtensibleValue<T>> {
    private final Function<String, T> factory;
    private final UnaryOperator<String> normalizer;
    private final Map<String, T> baseValues = new LinkedHashMap<>();
    private final Map<String, T> additionalValues = new LinkedHashMap<>();

    public ExtensibleValueRegistry(Function<String, T> factory, UnaryOperator<String> normalizer) {
        this.factory = Objects.requireNonNull(factory, "factory");
        this.normalizer = Objects.requireNonNull(normalizer, "normalizer");
    }

    public synchronized T registerBase(String name) {
        String normalized = normalize(name);
        T existing = this.baseValues.get(normalized);
        if (existing != null) {
            return existing;
        }
        T value = this.factory.apply(normalized);
        this.baseValues.put(normalized, value);
        this.additionalValues.remove(normalized);
        return value;
    }

    public synchronized T registerAdditional(String name) {
        String normalized = normalize(name);
        T base = this.baseValues.get(normalized);
        if (base != null) {
            return base;
        }
        return this.additionalValues.computeIfAbsent(normalized, this.factory);
    }

    public synchronized void replaceAdditional(Collection<String> names) {
        Map<String, T> replacement = new LinkedHashMap<>();
        for (String name : names) {
            String normalized = normalize(name);
            if (this.baseValues.containsKey(normalized) || replacement.containsKey(normalized)) {
                continue;
            }
            T existing = this.additionalValues.get(normalized);
            replacement.put(normalized, existing != null ? existing : this.factory.apply(normalized));
        }
        this.additionalValues.clear();
        this.additionalValues.putAll(replacement);
    }

    public synchronized void clearAdditional() {
        this.additionalValues.clear();
    }

    public synchronized T valueOf(String name) {
        String normalized = normalize(name);
        T value = this.baseValues.get(normalized);
        return value != null ? value : registerAdditional(normalized);
    }

    public synchronized List<T> values() {
        List<T> values = new ArrayList<>(this.baseValues.values());
        values.addAll(this.additionalValues.values());
        return List.copyOf(values);
    }

    private String normalize(String name) {
        String normalized = this.normalizer.apply(Objects.requireNonNull(name, "name"));
        if (normalized == null || normalized.isBlank()) {
            throw new IllegalArgumentException("Extensible value name cannot be blank");
        }
        return normalized;
    }
}
