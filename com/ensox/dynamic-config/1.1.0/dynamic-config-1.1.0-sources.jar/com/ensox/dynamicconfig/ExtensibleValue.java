package com.ensox.dynamicconfig;

import java.util.List;
import java.util.Objects;

/**
 * Enum-like configuration value whose option set can grow at runtime.
 * Subclasses own an {@link ExtensibleValueRegistry} containing their built-in
 * and dynamically discovered values.
 */
public abstract class ExtensibleValue<T extends ExtensibleValue<T>> {
    private final String name;

    protected ExtensibleValue(String name) {
        this.name = Objects.requireNonNull(name, "name");
        if (name.isBlank()) {
            throw new IllegalArgumentException("Extensible value name cannot be blank");
        }
    }

    public final String name() {
        return this.name;
    }

    protected abstract ExtensibleValueRegistry<T> registry();

    public final List<T> availableValues() {
        return this.registry().values();
    }

    @Override
    public final boolean equals(Object other) {
        return this == other || other != null
            && this.getClass() == other.getClass()
            && this.name.equals(((ExtensibleValue<?>) other).name);
    }

    @Override
    public final int hashCode() {
        return Objects.hash(this.getClass(), this.name);
    }

    @Override
    public String toString() {
        return this.name;
    }
}
