package com.ensox.dynamicconfig.events;

import com.ensox.dynamicconfig.events.bus.EventFactory;

public interface ConfigEvents {
	EventFactory.Event<ConfigSave> SAVE = EventFactory.createArrayBacked(ConfigSave.class, (listeners) -> () -> {
		for (ConfigSave event : listeners) {
			event.onConfigSave();
		}
	});

	EventFactory.Event<ConfigChange> CHANGE = EventFactory.createArrayBacked(ConfigChange.class, (listeners) -> () -> {
		for (ConfigChange event : listeners) {
			event.onConfigChange();
		}
	});

	interface ConfigSave {
		void onConfigSave();
	}

	interface ConfigChange {
		void onConfigChange();
	}
}
