package com.ensox.dynamicconfig.events.bus;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.List;

public class EventFactory {
	@SuppressWarnings("unchecked")
	public static <T> Event<T> createArrayBacked(Class<? super T> type, EventInvokerFactory<T> invokerFactory) {
		return new Event<>(type, invokerFactory);
	}

	@FunctionalInterface
	public interface EventInvokerFactory<T> {
		T create(T[] listeners);
	}

	public static class Event<T> {
		private final List<T> listeners = new ArrayList<>();
		private final EventInvokerFactory<T> invokerFactory;
		private final Class<?> listenerClass;
		private T invoker;

		@SuppressWarnings("unchecked")
		public Event(Class<? super T> listenerClass, EventInvokerFactory<T> invokerFactory) {
			this.listenerClass = listenerClass;
			this.invokerFactory = invokerFactory;
			updateInvoker();
		}

		public T invoker() {
			return invoker;
		}

		public void register(T listener) {
			listeners.add(listener);
			updateInvoker();
		}

		@SuppressWarnings("unchecked")
		private void updateInvoker() {
			T[] listenerArray = (T[]) Array.newInstance(listenerClass, listeners.size());
			invoker = invokerFactory.create(listeners.toArray(listenerArray));
		}
	}
}