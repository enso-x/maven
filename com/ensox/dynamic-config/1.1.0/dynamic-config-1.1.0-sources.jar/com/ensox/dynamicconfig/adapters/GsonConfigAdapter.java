package com.ensox.dynamicconfig.adapters;

import com.ensox.dynamicconfig.DynamicConfig;
import com.ensox.dynamicconfig.interfaces.DynamicConfigAdapter;
import com.google.gson.*;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Objects;
import java.util.function.Consumer;

public class GsonConfigAdapter<T> implements DynamicConfigAdapter<T> {
    private static final System.Logger LOGGER = System.getLogger(GsonConfigAdapter.class.getName());

    private final Gson gson;
    private final Class<T> configClass;
    private final Path configPath;
    private T configuration;
    private boolean createdFromDefaults;

    public GsonConfigAdapter(Class<T> configClass, Path configPath) {
        this(configClass, configPath, builder -> builder.setPrettyPrinting());
    }

    public GsonConfigAdapter(Class<T> configClass, Path configPath, Consumer<GsonBuilder> builderConsumer) {
        this.configClass = Objects.requireNonNull(configClass, "configClass");
        this.configPath = Objects.requireNonNull(configPath, "configPath");

        GsonBuilder builder = new GsonBuilder();
        builderConsumer.accept(builder);
        this.gson = builder.create();
    }

    @Override
    public void load(DynamicConfig.ConfigManager<T, ? extends DynamicConfigAdapter<T>> manager) {
        if (Files.notExists(configPath)) {
            this.createdFromDefaults = true;
            this.configuration = manager.getConfig();
            if (writesDefaultsOnCreate()) {
                save(manager);
            }
            return;
        }

        try (BufferedReader reader = Files.newBufferedReader(configPath, StandardCharsets.UTF_8)) {
            JsonElement overrides = normalizeOverrides(JsonParser.parseReader(reader));
            JsonElement base = this.gson.toJsonTree(manager.getConfig());
            merge(base, overrides);

            T loaded = this.gson.fromJson(base, configClass);
            if (loaded != null) {
                this.configuration = manager.copyInto(loaded, manager.getConfig());
            }
        } catch (JsonParseException | IllegalStateException e) {
            // The file is malformed or uses an incompatible older schema. Starting the game
            // matters more than the file: keep a copy for the user and continue with defaults.
            recoverFromUnreadableConfig(manager, e);
        } catch (IOException e) {
            throw new RuntimeException("Failed to load config from " + configPath, e);
        }
    }

    private void recoverFromUnreadableConfig(DynamicConfig.ConfigManager<T, ? extends DynamicConfigAdapter<T>> manager,
                                             RuntimeException cause) {
        Path backup = configPath.resolveSibling(configPath.getFileName() + ".broken-" + System.currentTimeMillis());
        try {
            Files.move(configPath, backup);
        } catch (IOException moveError) {
            cause.addSuppressed(moveError);
            backup = null;
        }
        LOGGER.log(System.Logger.Level.ERROR,
            "Config " + configPath + " could not be read and was reset to defaults"
                + (backup != null ? "; the original was kept as " + backup : ""), cause);
        this.createdFromDefaults = true;
        this.configuration = manager.getConfig();
        if (writesDefaultsOnCreate()) {
            save(manager);
        }
    }

    /**
     * Whether a load without a usable file writes the class defaults right away.
     * Adapters whose real defaults are filled in later (and saved then) return
     * {@code false}: if the session ends before that, the file stays absent and
     * the next launch is still treated as a first launch.
     */
    protected boolean writesDefaultsOnCreate() {
        return true;
    }

    /** Whether the last load had no usable file and wrote the class defaults (first launch or reset). */
    public boolean createdFromDefaults() {
        return createdFromDefaults;
    }

    @Override
    public void save(DynamicConfig.ConfigManager<T, ? extends DynamicConfigAdapter<T>> manager) {
        ensureParentExists(configPath);

        try (BufferedWriter writer = Files.newBufferedWriter(configPath, StandardCharsets.UTF_8)) {
            gson.toJson(prepareForWrite(gson.toJsonTree(manager.getConfig())), writer);
        } catch (IOException e) {
            throw new RuntimeException("Failed to save config to " + configPath, e);
        }
    }

    @Override
    public T copy(T config) {
        return gson.fromJson(gson.toJsonTree(config), configClass);
    }

    @Override
    public void saveDocument(T config, Path file) {
        Objects.requireNonNull(file, "document file");
        ensureParentExists(file);

        try (Writer writer = Files.newBufferedWriter(file, StandardCharsets.UTF_8)) {
            gson.toJson(prepareForWrite(gson.toJsonTree(config)), writer);
        } catch (IOException e) {
            throw new RuntimeException("Failed to save document to " + file, e);
        }
    }

    @Override
    public T loadDocument(Path file, Class<T> requestedClass) {
        Objects.requireNonNull(file, "document file");
        Class<T> effectiveClass = requestedClass == null ? this.configClass : requestedClass;

        if (Files.notExists(file)) {
            throw new IllegalArgumentException("Document file does not exist: " + file);
        }

        try (Reader reader = Files.newBufferedReader(file, StandardCharsets.UTF_8)) {
            JsonElement overrides = normalizeOverrides(JsonParser.parseReader(reader));
            JsonElement base = this.gson.toJsonTree(this.configuration);
            merge(base, overrides);
            return this.gson.fromJson(base, effectiveClass);
        } catch (IOException e) {
            throw new RuntimeException("Failed to load document from " + file, e);
        }
    }

    @Override
    public T loadDocument(InputStream stream, Class<T> requestedClass) {
        Class<T> effectiveClass = requestedClass == null ? this.configClass : requestedClass;

        try (Reader reader = new InputStreamReader(stream)) {
            JsonElement overrides = normalizeOverrides(JsonParser.parseReader(reader));
            JsonElement base = this.gson.toJsonTree(this.configuration);
            merge(base, overrides);
            return this.gson.fromJson(base, effectiveClass);
        } catch (IOException e) {
            throw new RuntimeException("Failed to load document from " + stream, e);
        }
    }

    @Override
    public boolean removeDocument(Path file) {
        Objects.requireNonNull(file, "document file");

        try {
            return Files.deleteIfExists(file);
        } catch (IOException e) {
            throw new RuntimeException("Failed to delete document " + file, e);
        }
    }

    public Gson getGson() {
        return this.gson;
    }

    /** Allows an adapter to leave out settings that must not be persisted (the config file and documents). */
    protected JsonElement prepareForWrite(JsonElement tree) {
        return tree;
    }

    /** Allows an adapter to normalize legacy persisted shapes before they are merged. */
    protected JsonElement normalizeOverrides(JsonElement overrides) {
        return overrides;
    }

    private static void merge(JsonElement target, JsonElement overrides) {
        if (!(target instanceof JsonObject targetObj) || overrides == null || !overrides.isJsonObject()) {
            return;
        }
        JsonObject overrideObj = overrides.getAsJsonObject();
        for (var entry : overrideObj.entrySet()) {
            JsonElement overrideValue = entry.getValue();
            if (overrideValue != null && overrideValue.isJsonObject()) {
                JsonElement existing = targetObj.get(entry.getKey());
                if (existing != null && existing.isJsonObject()) {
                    merge(existing, overrideValue);
                    continue;
                }
            }
            targetObj.add(entry.getKey(), overrideValue);
        }
    }

    private static void ensureParentExists(Path path) {
        Path parent = path.getParent();
        if (parent != null) {
            try {
                Files.createDirectories(parent);
            } catch (IOException e) {
                throw new RuntimeException("Failed to create directories for " + path, e);
            }
        }
    }
}
