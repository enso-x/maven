package com.ensox.dynamicconfig.interfaces;

import com.ensox.dynamicconfig.DynamicConfig;

import java.io.InputStream;
import java.nio.file.Path;

public interface DynamicConfigAdapter<T> {
    /** Вызывается сразу после сборки ConfigManager (можно зарегистрировать type-adapter’ы и т.п.). */
    default void initialize(DynamicConfig.ConfigManager<T, ? extends DynamicConfigAdapter<T>> manager) {}

    /** Загружает данные в manager.getConfig(). Если файла нет – создаёт дефолт и вызывает save(). */
    void load(DynamicConfig.ConfigManager<T, ? extends DynamicConfigAdapter<T>> manager);

    /** Сохраняет текущее состояние manager.getConfig(). */
    void save(DynamicConfig.ConfigManager<T, ? extends DynamicConfigAdapter<T>> manager);

    /** Делает глубокую копию конфигурации (используется для пресетов/копий). */
    T copy(T config);

    /** Сохраняет произвольный экземпляр (например, пресет) в заданный путь. */
    void saveDocument(T config, Path file);

    /** Загружает конфигурацию из произвольного файла без изменения глобального состояния. */
    T loadDocument(Path file, Class<T> configClass);

    default T loadDocument(InputStream stream, Class<T> configClass) {
        throw new UnsupportedOperationException("Stream documents not supported");
    }

    /** Удаляет файл пресета. */
    default boolean removeDocument(Path file) {
        throw new UnsupportedOperationException("Document removal not supported");
    }

    // ---- 1.0.0 names (see ConfigManager): callers compiled against 1.0.0 keep working. ----

    /** @deprecated since 1.1.0, use {@link #saveDocument}. */
    @Deprecated(since = "1.1.0")
    default void savePreset(T config, Path file) {
        saveDocument(config, file);
    }

    /** @deprecated since 1.1.0, use {@link #loadDocument(Path, Class)}. */
    @Deprecated(since = "1.1.0")
    default T loadPreset(Path file, Class<T> configClass) {
        return loadDocument(file, configClass);
    }

    /** @deprecated since 1.1.0, use {@link #loadDocument(InputStream, Class)}. */
    @Deprecated(since = "1.1.0")
    default T loadPreset(InputStream stream, Class<T> configClass) {
        return loadDocument(stream, configClass);
    }

    /** @deprecated since 1.1.0, use {@link #removeDocument}. */
    @Deprecated(since = "1.1.0")
    default boolean removePreset(Path file) {
        return removeDocument(file);
    }
}
