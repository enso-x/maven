package com.ensox.dynamicconfig;

import com.ensox.dynamicconfig.events.ConfigEvents;
import com.ensox.dynamicconfig.interfaces.DynamicConfigAdapter;

import java.io.InputStream;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import java.lang.reflect.Array;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.RecordComponent;
import java.lang.reflect.Type;
import java.nio.file.Path;
import java.text.MessageFormat;
import java.util.*;

public class DynamicConfig {
    @Target(ElementType.TYPE)
    @Retention(RetentionPolicy.RUNTIME)
    public @interface Configuration {
    }

    @Target(ElementType.TYPE)
    @Retention(RetentionPolicy.RUNTIME)
    public @interface Category {
        String name();
        String key();
        CategoryType type() default CategoryType.OBJECT;
        String[] groups() default {};
        boolean root() default false;
        boolean display() default true;
        DisplayCondition[] displayIf() default {};
        ConditionMode displayMode() default ConditionMode.ALL;
    }

    public enum CategoryType {
        OBJECT,
        LIST,
        ARRAY
    }

    @Target(ElementType.FIELD)
    @Retention(RetentionPolicy.RUNTIME)
    public @interface Field {
        String[] groups() default {};
        double min() default Double.NaN;
        double max() default Double.NaN;
        double step() default 1.0D;
        boolean display() default true;
        DisplayCondition[] displayIf() default {};
        ConditionMode displayMode() default ConditionMode.ALL;
        String widget() default "";
        String[] custom() default {};
        /** Unit shown next to the value and used for formatting (for example {@code PERCENT} shows 0..1 as 0..100%). */
        Unit unit() default Unit.NONE;
        /** Displayed decimal places; {@code -1} derives them from {@code step}. */
        int decimals() default -1;
        /**
         * Field whose color previews this value (opacity sliders show the color
         * they fade). A bare name refers to a field of the same category.
         * Validated at metadata discovery.
         */
        String previewColor() default "";
        /** Where the value may be set; see {@link Scope}. */
        Scope scope() default Scope.ANY;
        /**
         * Application-defined evaluation context of the value (for example
         * {@code "particle"}): where it is computed, and so which inputs a
         * value driven by a curve may follow. Empty means the default context.
         */
        String context() default "";
    }

    /** Display unit of a numeric field. */
    public enum Unit {
        NONE,
        BLOCKS,
        TICKS,
        SECONDS,
        PERCENT,
        DEGREES,
        PER_SECOND,
        PIXELS
    }

    /**
     * {@code ANY}: per configuration (global, documents, item overrides).
     * {@code GLOBAL}: only the global configuration is consulted at runtime;
     * editors for documents and item overrides hide the field.
     */
    public enum Scope {
        ANY,
        GLOBAL
    }

    @Target({})
    @Retention(RetentionPolicy.RUNTIME)
    public @interface DisplayCondition {
        String field();
        String[] values();
        Comparison comparison() default Comparison.EQUALS;
    }

    public enum ConditionMode {
        ALL,
        ANY
    }

    public enum Comparison {
        EQUALS,
        NOT_EQUALS
    }

    @Target(ElementType.FIELD)
    @Retention(RetentionPolicy.RUNTIME)
    public @interface Widget {
        String value();
        String[] custom() default {};
    }

    public static final class Group {
        public static final String DEFAULT = "default";

        private Group() {}
    }

    public interface ValueMeta {
        Object defaultValue();

        <V> V getValue(Object configRoot);

        void setValue(Object configRoot, Object value);
    }

    @FunctionalInterface
    public interface HashAdapter<V> {
        long hash(V value, HashContext context);
    }

    public static final class HashContext {
        private final ConfigManager<?, ?> manager;

        private HashContext(ConfigManager<?, ?> manager) {
            this.manager = manager;
        }

        public long hashValue(Type declaredType, Object value) {
            return this.manager.hashValue(declaredType, value);
        }

        public long hashValue(Object value) {
            return this.manager.hashValue(value);
        }

        public long hashString(String value) {
            return DynamicConfig.hashString(value);
        }

        public long mix(long hash, long value) {
            return DynamicConfig.mixHash(hash, value);
        }
    }

    public record CategoryHashSnapshot(Map<String, Long> sectionHashes, long totalHash) {
        private static final CategoryHashSnapshot EMPTY = new CategoryHashSnapshot(Map.of(), 0L);

        public long sectionHash(String sectionKey) {
            return this.sectionHashes.getOrDefault(sectionKey, 0L);
        }
    }

    public static final long HASH_SEED = 0xCBF29CE484222325L;
    public static final long HASH_PRIME = 0x100000001B3L;

    public static long mixHash(long hash, long value) {
        hash ^= value;
        return hash * HASH_PRIME;
    }

    public static long hashString(String value) {
        if (value == null) {
            return 0L;
        }

        long hash = mixHash(HASH_SEED, value.length());
        for (int i = 0; i < value.length(); i++) {
            hash = mixHash(hash, value.charAt(i));
        }
        return hash;
    }

    public static <T, S extends DynamicConfigAdapter<T>> ConfigManager<T, S> createConfigurationManager(String modId,
                                                                  Class<T> configurationClass,
                                                                  S configurationAdapter) {
        return new ConfigManager<>(modId, configurationClass, configurationAdapter);
    }

    public static <T, S extends DynamicConfigAdapter<T>> ConfigManager<T, S> load(String modId,
                                            Class<T> configClass,
                                            S configAdapter) {
        return createConfigurationManager(modId, configClass, configAdapter).load();
    }

    public static final class CategoryMeta implements ValueMeta {
        private final String key;
        private final String name;
        private final CategoryType type;
        private final String[] groups;
        private final boolean root;
        private final boolean display;
        private final List<VisibilityCondition> displayConditions;
        private final ConditionMode displayMode;
        private final String translationKey;
        private final java.lang.reflect.Field configField;
        private final Class<?> valueType;
        private final Type genericType;
        private final Class<?> elementType;
        private final Object defaultValue;

        private CategoryMeta(String modId, java.lang.reflect.Field configField, Category category, Object defaultValue) {
            this.key = Objects.requireNonNull(category.key(), "Category key cannot be null");
            this.name = Objects.requireNonNull(category.name(), "Category name cannot be null");
            this.type = Objects.requireNonNull(category.type(), "Category type cannot be null");
            this.groups = Objects.requireNonNullElse(category.groups(), new String[]{}).clone();
            this.root = category.root();
            this.display = category.display();
            this.displayConditions = copyConditions(category.displayIf());
            this.displayMode = category.displayMode();
            this.translationKey = MessageFormat.format("{0}.config.{1}", modId, this.key);
            this.configField = configField;
            this.configField.setAccessible(true);
            this.valueType = configField.getType();
            this.genericType = configField.getGenericType();
            this.elementType = resolveElementType(this.type, this.valueType, this.genericType);
            this.defaultValue = defaultValue;
            if (configField.isAnnotationPresent(DynamicConfig.Field.class)) {
                throw new IllegalStateException(
                    "Category '" + this.key + "' must not also be annotated with @DynamicConfig.Field"
                );
            }
            validateCategoryType(this.key, this.type, this.valueType, this.elementType);
        }

        public String key() {
            return key;
        }

        public String name() {
            return name;
        }

        public CategoryType type() {
            return this.type;
        }

        public String[] groups() {
            return this.groups.clone();
        }

        public boolean root() {
            return root;
        }

        public boolean display() {
            return display;
        }

        public List<VisibilityCondition> displayConditions() {
            return this.displayConditions;
        }

        public ConditionMode displayMode() {
            return this.displayMode;
        }

        public String translationKey() {
            return translationKey;
        }

        public Class<?> valueType() {
            return this.valueType;
        }

        public Type genericType() {
            return this.genericType;
        }

        public Class<?> elementType() {
            return this.elementType;
        }

        @Override
        public Object defaultValue() {
            return this.defaultValue;
        }

        @Override
        @SuppressWarnings("unchecked")
        public <V> V getValue(Object configRoot) {
            return (V) this.getInstance(configRoot);
        }

        @Override
        public void setValue(Object configRoot, Object value) {
            try {
                this.configField.set(configRoot, value);
            } catch (IllegalAccessException e) {
                throw new IllegalStateException("Failed to update category '" + this.key + "'", e);
            }
        }

        public Object getInstance(Object configRoot) {
            try {
                return configField.get(configRoot);
            } catch (IllegalAccessException e) {
                throw new IllegalStateException("Failed to access category '" + key + "'", e);
            }
        }

        @Override
        public String toString() {
            return "CategoryMeta{" +
                "key='" + key + '\'' +
                ", name='" + name + '\'' +
                ", type=" + type +
                ", root=" + root +
                ", display=" + display +
                '}';
        }

        private static Class<?> resolveElementType(CategoryType type, Class<?> valueType, Type genericType) {
            if (type == CategoryType.ARRAY) {
                return valueType.isArray() ? valueType.getComponentType() : null;
            }
            if (type != CategoryType.LIST || !(genericType instanceof ParameterizedType parameterizedType)) {
                return type == CategoryType.OBJECT ? valueType : null;
            }

            return rawClass(parameterizedType.getActualTypeArguments()[0]);
        }

        private static void validateCategoryType(String key, CategoryType type, Class<?> valueType, Class<?> elementType) {
            if (type == CategoryType.OBJECT && (List.class.isAssignableFrom(valueType) || valueType.isArray())) {
                throw new IllegalStateException(
                    "Category '" + key + "' must explicitly declare LIST or ARRAY for " + valueType.getName()
                );
            }
            if (type == CategoryType.LIST && !List.class.isAssignableFrom(valueType)) {
                throw new IllegalStateException("Category '" + key + "' is LIST but its field type is " + valueType.getName());
            }
            if (type == CategoryType.ARRAY && !valueType.isArray()) {
                throw new IllegalStateException("Category '" + key + "' is ARRAY but its field type is " + valueType.getName());
            }
            if (type != CategoryType.OBJECT && elementType == null) {
                throw new IllegalStateException("Category '" + key + "' must declare a concrete element type");
            }
        }
    }

    public static final class FieldMeta implements ValueMeta {
        private final String id;
        private final String key;
        private final String translationKey;
        private final String translationDescriptionKey;
        private final CategoryMeta category;
        private final String[] groups;
        private final Class<?> type;
        private final Type genericType;
        private final List<Type> typeArguments;
        private final Object defaultValue;
        private final boolean display;
        private final List<VisibilityCondition> displayConditions;
        private final ConditionMode displayMode;
        private final Double min;
        private final Double max;
        private final Double step;
        private final String widget;
        private final List<String> custom;
        private final Map<String, String> customMap;
        private final Unit unit;
        private final int decimals;
        private final String previewColorRef;
        private final String context;
        private final Scope scope;
        private FieldMeta previewColor;
        private final java.lang.reflect.Field fieldRef;

        private FieldMeta(String modId,
                          CategoryMeta category,
                          java.lang.reflect.Field fieldRef,
                          DynamicConfig.Field fieldAnnotation,
                          Object defaultValue) {
            this.category = category;
            this.fieldRef = fieldRef;
            this.fieldRef.setAccessible(true);
            this.key = fieldRef.getName();
            this.id = category.key() + "." + this.key;
            this.translationKey = MessageFormat.format("{0}.config.{1}.{2}", modId, category.key(), this.key);
            this.translationDescriptionKey = this.translationKey + ".description";
            this.groups = Objects.requireNonNullElse(fieldAnnotation.groups(), new String[]{Group.DEFAULT});
            this.display = fieldAnnotation.display();
            this.displayConditions = copyConditions(fieldAnnotation.displayIf());
            this.displayMode = fieldAnnotation.displayMode();
            this.type = fieldRef.getType();
            this.genericType = fieldRef.getGenericType();
            if (this.genericType instanceof ParameterizedType parameterizedType) {
                this.typeArguments = Collections.unmodifiableList(Arrays.asList(parameterizedType.getActualTypeArguments()));
            } else {
                this.typeArguments = List.of();
            }
            this.defaultValue = defaultValue;
            this.min = Double.isNaN(fieldAnnotation.min()) ? null : fieldAnnotation.min();
            this.max = Double.isNaN(fieldAnnotation.max()) ? null : fieldAnnotation.max();
            this.step = Double.isNaN(fieldAnnotation.step()) ? null : fieldAnnotation.step();

            Widget widgetAnnotation = fieldRef.getAnnotation(Widget.class);
            if (widgetAnnotation != null) {
                this.widget = Objects.requireNonNullElse(widgetAnnotation.value(), "");
                this.custom = List.copyOf(Arrays.asList(Objects.requireNonNullElse(widgetAnnotation.custom(), new String[]{})));
            } else {
                this.widget = Objects.requireNonNullElse(fieldAnnotation.widget(), "");
                this.custom = List.copyOf(Arrays.asList(Objects.requireNonNullElse(fieldAnnotation.custom(), new String[]{})));
            }
            this.customMap = buildCustomMap(this.custom);
            this.unit = fieldAnnotation.unit();
            this.decimals = fieldAnnotation.decimals();
            this.previewColorRef = fieldAnnotation.previewColor();
            this.context = fieldAnnotation.context();
            this.scope = fieldAnnotation.scope();
        }

        public Unit unit() {
            return unit;
        }

        /** Displayed decimal places, or {@code -1} to derive them from {@link #step()}. */
        public int decimals() {
            return decimals;
        }

        public Scope scope() {
            return scope;
        }

        /** The field whose color previews this one, resolved at discovery; {@code null} if none. */
        /** Evaluation context id from the annotation; empty for the default. */
        public String context() {
            return context;
        }

        public FieldMeta previewColor() {
            return previewColor;
        }

        public String id() {
            return id;
        }

        public String key() {
            return key;
        }

        public String translationKey() {
            return translationKey;
        }

        public String translationDescriptionKey() {
            return translationDescriptionKey;
        }

        public CategoryMeta category() {
            return category;
        }

        public String[] groups() {
            return groups;
        }

        public Class<?> type() {
            return type;
        }

        public Type genericType() {
            return genericType;
        }

        public List<Type> typeArguments() {
            return typeArguments;
        }

        @Override
        public Object defaultValue() {
            return defaultValue;
        }

        public boolean display() {
            return display;
        }

        public List<VisibilityCondition> displayConditions() {
            return this.displayConditions;
        }

        public ConditionMode displayMode() {
            return this.displayMode;
        }

        public boolean hasMin() {
            return min != null;
        }

        public boolean hasMax() {
            return max != null;
        }

        public boolean hasStep() {
            return step != null;
        }

        public double min() {
            return min == null ? 0.0D : min;
        }

        public double max() {
            return max == null ? Double.MAX_VALUE : max;
        }

        public double step() {
            return step == null ? 1 : step;
        }

        public boolean hasWidget() {
            return !this.widget.isEmpty();
        }

        public String widget() {
            return widget;
        }

        public List<String> custom() {
            return custom;
        }

        public Map<String, String> customMap() {
            return customMap;
        }

        @SuppressWarnings("unchecked")
        public <V> V getValue(Object configRoot) {
            try {
                return (V) fieldRef.get(category.getInstance(configRoot));
            } catch (IllegalAccessException e) {
                throw new IllegalStateException("Failed to read field '" + id + "'", e);
            }
        }

        public void setValue(Object configRoot, Object value) {
            try {
                fieldRef.set(category.getInstance(configRoot), value);
            } catch (IllegalAccessException e) {
                throw new IllegalStateException("Failed to set field '" + id + "'", e);
            }
        }

        /**
         * Reads this field from an instance of its category class directly, for
         * owners that are not reachable from the configuration root by path
         * (elements of LIST/ARRAY categories, nested categories inside them).
         */
        @SuppressWarnings("unchecked")
        public <V> V readFrom(Object categoryInstance) {
            try {
                return (V) fieldRef.get(categoryInstance);
            } catch (IllegalAccessException e) {
                throw new IllegalStateException("Failed to read field '" + id + "'", e);
            }
        }

        public void writeTo(Object categoryInstance, Object value) {
            try {
                fieldRef.set(categoryInstance, value);
            } catch (IllegalAccessException e) {
                throw new IllegalStateException("Failed to set field '" + id + "'", e);
            }
        }

        /** The Java class that declares this field (the category definition type). */
        public Class<?> declaringType() {
            return fieldRef.getDeclaringClass();
        }

        @Override
        public String toString() {
            return "FieldMeta{" +
                "id='" + id + '\'' +
                ", type=" + type.getSimpleName() +
                ", groups='" + Arrays.toString(groups) + '\'' +
                ", category=" + category.key() +
                '}';
        }

        private static String camelToSnake(String value) {
            return value
                .replaceAll("([a-z0-9])([A-Z])", "$1_$2")
                .replaceAll("([A-Z])([A-Z][a-z])", "$1_$2")
                .toLowerCase(Locale.ROOT);
        }

        private static Map<String, String> buildCustomMap(List<String> custom) {
            if (custom == null || custom.isEmpty()) {
                return Map.of();
            }
            Map<String, String> map = new LinkedHashMap<>();
            for (String entry : custom) {
                if (entry == null || entry.isBlank()) {
                    continue;
                }
                String key = entry;
                String value = "";
                int splitIndex = entry.indexOf('=');
                if (splitIndex >= 0) {
                    key = entry.substring(0, splitIndex).trim();
                    value = entry.substring(splitIndex + 1).trim();
                }
                if (!key.isEmpty()) {
                    map.put(key, value);
                }
            }
            return Map.copyOf(map);
        }
    }

    public record VisibilityCondition(String fieldId, List<String> values, Comparison comparison) {
        public VisibilityCondition {
            fieldId = Objects.requireNonNull(fieldId, "display condition field").trim();
            if (fieldId.isEmpty()) {
                throw new IllegalArgumentException("Display condition field cannot be blank");
            }
            values = List.copyOf(Objects.requireNonNull(values, "display condition values"));
            if (values.isEmpty() || values.stream().anyMatch(value -> value == null || value.isBlank())) {
                throw new IllegalArgumentException("Display condition values cannot be empty or blank");
            }
            comparison = Objects.requireNonNull(comparison, "display condition comparison");
        }

        public boolean matches(Object actualValue) {
            String actual = actualValue instanceof Enum<?> enumValue
                ? enumValue.name()
                : Objects.toString(actualValue, null);
            boolean equal = this.values.contains(actual);
            return this.comparison == Comparison.EQUALS ? equal : !equal;
        }
    }

    private static List<VisibilityCondition> copyConditions(DisplayCondition[] conditions) {
        if (conditions == null || conditions.length == 0) {
            return List.of();
        }
        return Arrays.stream(conditions)
            .map(condition -> new VisibilityCondition(
                condition.field(), Arrays.asList(condition.values()), condition.comparison()
            ))
            .toList();
    }

    private static Category findCategoryAnnotation(java.lang.reflect.Field field) {
        Class<?> definitionType = findCategoryDefinitionType(field);
        return definitionType == null ? null : definitionType.getAnnotation(Category.class);
    }

    private static Class<?> findCategoryDefinitionType(java.lang.reflect.Field field) {
        Class<?> valueType = field.getType();
        if (valueType.isAnnotationPresent(Category.class)) {
            return valueType;
        }
        if (valueType.isArray() && valueType.getComponentType().isAnnotationPresent(Category.class)) {
            return valueType.getComponentType();
        }
        if (!List.class.isAssignableFrom(valueType)
            || !(field.getGenericType() instanceof ParameterizedType parameterizedType)) {
            return null;
        }

        Type[] arguments = parameterizedType.getActualTypeArguments();
        Class<?> elementType = arguments.length == 1 ? rawClass(arguments[0]) : null;
        return elementType != null && elementType.isAnnotationPresent(Category.class)
            ? elementType
            : null;
    }

    private static Class<?> rawClass(Type type) {
        if (type instanceof Class<?> typeClass) {
            return typeClass;
        }
        if (type instanceof ParameterizedType parameterizedType
            && parameterizedType.getRawType() instanceof Class<?> rawType) {
            return rawType;
        }
        return null;
    }

    public static class ConfigManager<T, S extends DynamicConfigAdapter<T>> {
        private final String modId;
        private final S adapter;
        private final Map<String, FieldMeta> fieldsById;
        private final Map<String, FieldMeta> fieldsByName;
        private final Class<T> configClass;
        private final T configuration;
        private final Map<Type, HashAdapter<?>> hashAdapters = new LinkedHashMap<>();
        private final HashContext hashContext = new HashContext(this);
        /**
         * Fields of LIST/ARRAY category elements and of categories nested inside
         * them, keyed by category key. They are bound to an owner instance (an
         * element), not reachable from the configuration root, so they are kept
         * out of {@link #getFields()}; read them with {@link FieldMeta#readFrom}.
         */
        private final Map<String, List<FieldMeta>> ownerFields = new LinkedHashMap<>();
        private final Map<String, List<CategoryMeta>> nestedCategories = new LinkedHashMap<>();

        private final Map<T, Map<String, CategoryMeta>> categoriesCache =
            Collections.synchronizedMap(new WeakHashMap<>());
        private final Map<T, List<FieldMeta>> fieldsCache =
            Collections.synchronizedMap(new WeakHashMap<>());

        public ConfigManager(String modId,
                             Class<T> configurationClass,
                             S adapter) {
            this.modId = Objects.requireNonNull(modId, "modId");
            this.configClass = Objects.requireNonNull(configurationClass, "configurationClass");
            this.adapter = Objects.requireNonNull(adapter, "adapter");

            if (!configurationClass.isAnnotationPresent(Configuration.class)) {
                throw new IllegalArgumentException(
                    "Configuration class " + configurationClass.getName() + " must be annotated with @DynamicConfig.Configuration"
                );
            }

            try {
                this.configuration = configurationClass.getDeclaredConstructor().newInstance();
            } catch (ReflectiveOperationException e) {
                throw new IllegalStateException("Failed to instantiate configuration", e);
            }

            this.categoriesFor(this.configuration);
            var fields = this.fieldsFor(this.configuration);
            this.fieldsById = new LinkedHashMap<>();
            this.fieldsByName = new LinkedHashMap<>();
            for (FieldMeta field : fields) {
                if (fieldsById.putIfAbsent(field.id(), field) != null) {
                    throw new IllegalStateException("Duplicate field id detected: " + field.id());
                }
                fieldsByName.putIfAbsent(field.key(), field);
            }
            for (CategoryMeta category : this.categoriesFor(this.configuration).values()) {
                if (category.type() != CategoryType.OBJECT) {
                    this.discoverOwnerFields(category, category.elementType());
                }
            }

            this.validateDisplayConditions();

            this.registerDefaultHashAdapters();
            this.adapter.initialize(this);
        }

        private void discoverOwnerFields(CategoryMeta category, Class<?> type) {
            Object defaults = instantiate(type);
            List<FieldMeta> fields = new ArrayList<>();
            Class<?> current = type;
            while (current != null && current != Object.class) {
                for (java.lang.reflect.Field field : current.getDeclaredFields()) {
                    if (java.lang.reflect.Modifier.isStatic(field.getModifiers())) {
                        continue;
                    }
                    field.setAccessible(true);
                    Object defaultValue = readDefault(field, defaults);
                    DynamicConfig.Field annotation = field.getAnnotation(DynamicConfig.Field.class);
                    if (annotation != null) {
                        FieldMeta meta = new FieldMeta(this.modId, category, field, annotation, defaultValue);
                        if (this.fieldsById.putIfAbsent(meta.id(), meta) != null) {
                            throw new IllegalStateException("Duplicate field id detected: " + meta.id());
                        }
                        this.fieldsByName.putIfAbsent(meta.key(), meta);
                        fields.add(meta);
                        continue;
                    }
                    Category nested = field.getType().getAnnotation(Category.class);
                    if (nested != null) {
                        CategoryMeta nestedMeta = new CategoryMeta(this.modId, field, nested, defaultValue);
                        this.nestedCategories.computeIfAbsent(category.key(), k -> new ArrayList<>()).add(nestedMeta);
                        this.discoverOwnerFields(nestedMeta, field.getType());
                    }
                }
                current = current.getSuperclass();
            }
            this.ownerFields.put(category.key(), List.copyOf(fields));
        }

        private static Object instantiate(Class<?> type) {
            try {
                var constructor = type.getDeclaredConstructor();
                constructor.setAccessible(true);
                return constructor.newInstance();
            } catch (ReflectiveOperationException e) {
                return null;
            }
        }

        private static Object readDefault(java.lang.reflect.Field field, Object defaults) {
            if (defaults == null) {
                return null;
            }
            try {
                return field.get(defaults);
            } catch (IllegalAccessException e) {
                return null;
            }
        }

        /** Fields declared by a LIST/ARRAY element type or a nested category, see {@link #ownerFields}. */
        public List<FieldMeta> getOwnerFields(String categoryKey) {
            return this.ownerFields.getOrDefault(categoryKey, List.of());
        }

        /** Categories nested inside the given category's element or object type (for example particle trails). */
        public List<CategoryMeta> getNestedCategories(String categoryKey) {
            return List.copyOf(this.nestedCategories.getOrDefault(categoryKey, List.of()));
        }

        private Map<String, CategoryMeta> discoverCategories(T configuration) {
            Map<String, CategoryMeta> discovered = new LinkedHashMap<>();
            Class<?> current = configuration.getClass();
            while (current != null && current != Object.class) {
                for (java.lang.reflect.Field field : current.getDeclaredFields()) {
                    Category category = findCategoryAnnotation(field);
                    if (category == null) {
                        continue;
                    }
                    field.setAccessible(true);
                    Object defaultValue;
                    try {
                        defaultValue = field.get(configuration);
                    } catch (IllegalAccessException e) {
                        throw new IllegalStateException("Failed to read default category '" + category.key() + "'", e);
                    }
                    CategoryMeta meta = new CategoryMeta(this.modId, field, category, defaultValue);
                    if (discovered.putIfAbsent(meta.key(), meta) != null) {
                        throw new IllegalStateException("Duplicate category key '" + meta.key() + "'");
                    }
                }
                current = current.getSuperclass();
            }
            return discovered;
        }

        private List<FieldMeta> discoverFields(T configuration) {
            List<FieldMeta> discovered = new ArrayList<>();
            var categories = categoriesFor(configuration);
            for (CategoryMeta category : categories.values()) {
                if (category.type() != CategoryType.OBJECT) {
                    continue;
                }

                Object categoryInstance = category.getInstance(configuration);
                if (categoryInstance == null) {
                    continue;
                }

                Class<?> current = category.valueType();
                while (current != null && current != Object.class) {
                    for (java.lang.reflect.Field field : current.getDeclaredFields()) {
                        DynamicConfig.Field annotation = field.getAnnotation(DynamicConfig.Field.class);
                        if (annotation == null) {
                            continue;
                        }

                        field.setAccessible(true);
                        try {
                            Object defaultValue = field.get(categoryInstance);
                            discovered.add(new FieldMeta(this.modId, category, field, annotation, defaultValue));
                        } catch (IllegalAccessException e) {
                            throw new IllegalStateException("Failed to read default value for '" + field.getName() + "'", e);
                        }
                    }
                    current = current.getSuperclass();
                }
            }
            return discovered;
        }

        public String getModId() {
            return modId;
        }

        public Class<T> getConfigClass() {
            return configClass;
        }

        public S getAdapter() {
            return adapter;
        }

        public T getConfig() {
            return configuration;
        }

        private Map<String, CategoryMeta> categoriesFor(T configuration) {
            return categoriesCache.computeIfAbsent(configuration, cfg -> Collections.unmodifiableMap(this.discoverCategories(cfg)));
        }

        private List<FieldMeta> fieldsFor(T configuration) {
            return fieldsCache.computeIfAbsent(configuration, cfg -> Collections.unmodifiableList(this.discoverFields(cfg)));
        }

        public Collection<CategoryMeta> getCategories() {
            return categoriesFor(this.configuration).values();
        }

        public Collection<CategoryMeta> getCategories(T configuration) {
            return categoriesFor(configuration).values();
        }

        public CategoryMeta getCategory(String categoryKey) {
            return categoriesFor(this.configuration).get(categoryKey);
        }

        public CategoryMeta getCategory(T configuration, String categoryKey) {
            return categoriesFor(configuration).get(categoryKey);
        }

        public List<CategoryMeta> getCategoriesByGroup(String group) {
            return getCategoriesByGroup(this.configuration, group);
        }

        public List<CategoryMeta> getCategoriesByGroup(T configuration, String group) {
            if (configuration == null || group == null) {
                return List.of();
            }
            return categoriesFor(configuration).values().stream()
                .filter(category -> Arrays.asList(category.groups()).contains(group))
                .toList();
        }

        public FieldMeta getFieldById(String fieldId) {
            return fieldsById.get(fieldId);
        }

        public FieldMeta getFieldByName(String fieldName) {
            return fieldsByName.get(fieldName);
        }

        public List<FieldMeta> getFields() {
            return fieldsFor(this.configuration);
        }

        /**
         * Every field by id: those of {@link #getFields()} and those of LIST/ARRAY elements
         * and nested categories ({@link #getOwnerFields}), which only {@link FieldMeta#readFrom}
         * and {@link FieldMeta#writeTo} reach.
         */
        public java.util.Collection<FieldMeta> getAllFields() {
            return Collections.unmodifiableCollection(fieldsById.values());
        }

        public List<FieldMeta> getFields(T configuration) {
            return fieldsFor(configuration);
        }

        public List<FieldMeta> getFieldsByCategory(String categoryKey) {
            if (categoryKey == null) {
                return List.of();
            }
            List<FieldMeta> result = new ArrayList<>();
            for (FieldMeta field : fieldsFor(this.configuration)) {
                if (categoryKey.equals(field.category().key())) {
                    result.add(field);
                }
            }
            return List.copyOf(result);
        }

        public List<FieldMeta> getFieldsByCategory(T configuration, String categoryKey) {
            if (categoryKey == null) {
                return List.of();
            }
            List<FieldMeta> result = new ArrayList<>();
            for (FieldMeta field : fieldsFor(configuration)) {
                if (categoryKey.equals(field.category().key())) {
                    result.add(field);
                }
            }
            return List.copyOf(result);
        }

        public List<FieldMeta> getFieldsByGroup(String group) {
            if (group == null) {
                return List.of();
            }
            List<FieldMeta> result = new ArrayList<>();
            for (FieldMeta field : fieldsFor(this.configuration)) {
                if (Arrays.stream(field.groups()).toList().contains(group)) {
                    result.add(field);
                }
            }
            return List.copyOf(result);
        }

        public List<FieldMeta> getFieldsByGroup(T configuration, String group) {
            if (group == null) {
                return List.of();
            }
            List<FieldMeta> result = new ArrayList<>();
            for (FieldMeta field : fieldsFor(configuration)) {
                if (Arrays.stream(field.groups()).toList().contains(group)) {
                    result.add(field);
                }
            }
            return List.copyOf(result);
        }

        public List<FieldMeta> getFieldsByCategoryAndGroup(String categoryKey, String group) {
            if (categoryKey == null || group == null) {
                return List.of();
            }
            List<FieldMeta> result = new ArrayList<>();
            for (FieldMeta field : fieldsFor(this.configuration)) {
                if (categoryKey.equals(field.category().key()) && Arrays.stream(field.groups()).toList().contains(group)) {
                    result.add(field);
                }
            }
            return List.copyOf(result);
        }

        public List<FieldMeta> getFieldsByCategoryAndGroup(T configuration, String categoryKey, String group) {
            if (categoryKey == null || group == null) {
                return List.of();
            }
            List<FieldMeta> result = new ArrayList<>();
            for (FieldMeta field : fieldsFor(configuration)) {
                if (categoryKey.equals(field.category().key()) && Arrays.stream(field.groups()).toList().contains(group)) {
                    result.add(field);
                }
            }
            return List.copyOf(result);
        }

        public boolean isDisplayed(CategoryMeta category, T configuration) {
            return isDisplayed(category, field -> field.getValue(configuration));
        }

        public boolean isDisplayed(CategoryMeta category, java.util.function.Function<FieldMeta, Object> valueResolver) {
            return category.display() && matchesDisplayConditions(
                category.displayConditions(), category.displayMode(), valueResolver
            );
        }

        public boolean isDisplayed(FieldMeta field, T configuration) {
            return isDisplayed(field, dependency -> dependency.getValue(configuration));
        }

        public boolean isDisplayed(FieldMeta field, java.util.function.Function<FieldMeta, Object> valueResolver) {
            return field.display() && matchesDisplayConditions(
                field.displayConditions(), field.displayMode(), valueResolver
            );
        }

        public List<FieldMeta> getDisplayDependencies(CategoryMeta category) {
            return resolveDisplayDependencies(category.displayConditions());
        }

        public List<FieldMeta> getDisplayDependencies(FieldMeta field) {
            return resolveDisplayDependencies(field.displayConditions());
        }

        private boolean matchesDisplayConditions(List<VisibilityCondition> conditions, ConditionMode mode,
                                                 java.util.function.Function<FieldMeta, Object> valueResolver) {
            if (conditions.isEmpty()) {
                return true;
            }
            java.util.function.Predicate<VisibilityCondition> matches = condition -> {
                FieldMeta dependency = requireDisplayDependency(condition.fieldId());
                return condition.matches(valueResolver.apply(dependency));
            };
            return mode == ConditionMode.ALL
                ? conditions.stream().allMatch(matches)
                : conditions.stream().anyMatch(matches);
        }

        private List<FieldMeta> resolveDisplayDependencies(List<VisibilityCondition> conditions) {
            return conditions.stream()
                .map(condition -> requireDisplayDependency(condition.fieldId()))
                .distinct()
                .toList();
        }

        private FieldMeta requireDisplayDependency(String fieldId) {
            FieldMeta field = this.fieldsById.get(fieldId);
            if (field == null && !fieldId.contains(".")) {
                field = this.fieldsByName.get(fieldId);
            }
            if (field == null) {
                throw new IllegalStateException("Unknown display condition field '" + fieldId + "'");
            }
            return field;
        }

        private void validateDisplayConditions() {
            for (CategoryMeta category : getCategories()) {
                resolveDisplayDependencies(category.displayConditions());
            }
            for (FieldMeta field : this.fieldsById.values()) {
                resolveDisplayDependencies(field.displayConditions());
                if (!field.previewColorRef.isEmpty()) {
                    String id = field.previewColorRef.contains(".")
                        ? field.previewColorRef
                        : field.category().key() + "." + field.previewColorRef;
                    FieldMeta target = this.fieldsById.get(id);
                    if (target == null) {
                        throw new IllegalStateException("Unknown previewColor field '" + field.previewColorRef + "' on " + field.id());
                    }
                    field.previewColor = target;
                }
            }
        }

        public void registerHashAdapter(Type type, HashAdapter<?> adapter) {
            this.hashAdapters.put(
                Objects.requireNonNull(type, "hash adapter type"),
                Objects.requireNonNull(adapter, "hash adapter")
            );
        }

        public <V> void registerHashAdapter(Class<V> type, HashAdapter<? super V> adapter) {
            registerHashAdapter((Type) type, adapter);
        }

        public long hashValue(Object value) {
            return hashValue(value == null ? Object.class : value.getClass(), value);
        }

        public long hashValue(Type declaredType, Object value) {
            if (value == null) {
                return 0L;
            }

            HashAdapter<Object> adapter = findHashAdapter(declaredType, value.getClass());
            if (adapter != null) {
                return adapter.hash(value, this.hashContext);
            }
            return hashValueFallback(declaredType, value);
        }

        public long hashFieldValue(FieldMeta field, Object configRoot) {
            Objects.requireNonNull(field, "field");
            return hashValue(field.genericType(), field.getValue(configRoot));
        }

        public long hashCategory(String categoryKey) {
            return hashCategory(this.configuration, categoryKey);
        }

        public long hashCategory(T configuration, String categoryKey) {
            if (configuration == null || categoryKey == null) {
                return 0L;
            }

            CategoryMeta category = getCategory(configuration, categoryKey);
            if (category == null || category.getInstance(configuration) == null) {
                return 0L;
            }

            long hash = HASH_SEED;
            if (category.type() != CategoryType.OBJECT) {
                return mixHash(hash, hashValue(category.genericType(), category.getValue(configuration)));
            }
            for (FieldMeta field : getFieldsByCategory(configuration, categoryKey)) {
                hash = mixHash(hash, hashString(field.key()));
                hash = mixHash(hash, hashFieldValue(field, configuration));
            }
            return hash;
        }

        public CategoryHashSnapshot hashCategories() {
            return hashCategories(this.configuration);
        }

        public CategoryHashSnapshot hashCategories(T configuration) {
            if (configuration == null) {
                return CategoryHashSnapshot.EMPTY;
            }

            Map<String, Long> sectionHashes = new LinkedHashMap<>();
            for (CategoryMeta category : getCategories(configuration)) {
                sectionHashes.put(category.key(), hashCategory(configuration, category.key()));
            }

            long totalHash = HASH_SEED;
            for (Map.Entry<String, Long> sectionHash : sectionHashes.entrySet()) {
                totalHash = mixHash(totalHash, hashString(sectionHash.getKey()));
                totalHash = mixHash(totalHash, sectionHash.getValue());
            }
            return new CategoryHashSnapshot(Map.copyOf(sectionHashes), totalHash);
        }

        @SuppressWarnings("unchecked")
        private HashAdapter<Object> findHashAdapter(Type declaredType, Class<?> runtimeType) {
            HashAdapter<?> exact = this.hashAdapters.get(declaredType);
            if (exact != null) {
                return (HashAdapter<Object>) exact;
            }

            exact = this.hashAdapters.get(runtimeType);
            if (exact != null) {
                return (HashAdapter<Object>) exact;
            }

            for (Map.Entry<Type, HashAdapter<?>> entry : this.hashAdapters.entrySet()) {
                if (entry.getKey() instanceof Class<?> adapterType && adapterType.isAssignableFrom(runtimeType)) {
                    return (HashAdapter<Object>) entry.getValue();
                }
            }
            return null;
        }

        private void registerDefaultHashAdapters() {
            registerHashAdapter(Boolean.class, (Boolean value, HashContext context) -> Boolean.hashCode(value));
            registerHashAdapter(boolean.class, (Boolean value, HashContext context) -> Boolean.hashCode(value));
            registerHashAdapter(Byte.class, (Byte value, HashContext context) -> Byte.hashCode(value));
            registerHashAdapter(byte.class, (Byte value, HashContext context) -> Byte.hashCode(value));
            registerHashAdapter(Short.class, (Short value, HashContext context) -> Short.hashCode(value));
            registerHashAdapter(short.class, (Short value, HashContext context) -> Short.hashCode(value));
            registerHashAdapter(Integer.class, (Integer value, HashContext context) -> Integer.hashCode(value));
            registerHashAdapter(int.class, (Integer value, HashContext context) -> Integer.hashCode(value));
            registerHashAdapter(Long.class, (Long value, HashContext context) -> Long.hashCode(value));
            registerHashAdapter(long.class, (Long value, HashContext context) -> Long.hashCode(value));
            registerHashAdapter(Float.class, (Float value, HashContext context) -> Float.floatToIntBits(value));
            registerHashAdapter(float.class, (Float value, HashContext context) -> Float.floatToIntBits(value));
            registerHashAdapter(Double.class, (Double value, HashContext context) -> Long.hashCode(Double.doubleToLongBits(value)));
            registerHashAdapter(double.class, (Double value, HashContext context) -> Long.hashCode(Double.doubleToLongBits(value)));
            registerHashAdapter(Character.class, (Character value, HashContext context) -> Character.hashCode(value));
            registerHashAdapter(char.class, (Character value, HashContext context) -> Character.hashCode(value));
            registerHashAdapter(CharSequence.class, (CharSequence value, HashContext context) -> context.hashString(value.toString()));
            registerHashAdapter(Iterable.class, (Iterable value, HashContext context) -> {
                long hash = HASH_SEED;
                for (Object element : value) {
                    hash = context.mix(hash, context.hashValue(element));
                }
                return hash;
            });
        }

        private long hashValueFallback(Type declaredType, Object value) {
            Class<?> runtimeType = value.getClass();
            if (runtimeType.isEnum() && value instanceof Enum<?> enumValue) {
                return hashObject(enumValue.getDeclaringClass().getName(), enumValue.name());
            }
            if (runtimeType.isArray()) {
                return hashArray(runtimeType.getComponentType(), value);
            }
            if (runtimeType.isRecord()) {
                return hashRecord(value);
            }
            if (hasAnnotatedFields(runtimeType)) {
                return hashAnnotatedObject(value);
            }
            return hashObject(runtimeType.getName(), String.valueOf(value));
        }

        private static boolean hasAnnotatedFields(Class<?> type) {
            Class<?> current = type;
            while (current != null && current != Object.class) {
                for (java.lang.reflect.Field field : current.getDeclaredFields()) {
                    if (isConfigValueField(field)) {
                        return true;
                    }
                }
                current = current.getSuperclass();
            }
            return false;
        }

        private long hashAnnotatedObject(Object value) {
            long hash = HASH_SEED;
            Class<?> current = value.getClass();
            while (current != null && current != Object.class) {
                for (java.lang.reflect.Field field : current.getDeclaredFields()) {
                    if (!isConfigValueField(field)) {
                        continue;
                    }
                    field.setAccessible(true);
                    try {
                        hash = mixHash(hash, hashString(field.getName()));
                        hash = mixHash(hash, hashValue(field.getGenericType(), field.get(value)));
                    } catch (IllegalAccessException e) {
                        throw new IllegalStateException("Failed to hash annotated field '" + field.getName() + "'", e);
                    }
                }
                current = current.getSuperclass();
            }
            return hash;
        }

        private static boolean isConfigValueField(java.lang.reflect.Field field) {
            return field.isAnnotationPresent(DynamicConfig.Field.class)
                || findCategoryAnnotation(field) != null;
        }

        private long hashArray(Type componentType, Object value) {
            long hash = HASH_SEED;
            int length = Array.getLength(value);
            for (int i = 0; i < length; i++) {
                hash = mixHash(hash, hashValue(componentType, Array.get(value, i)));
            }
            return hash;
        }

        private long hashRecord(Object record) {
            long hash = HASH_SEED;
            for (RecordComponent component : record.getClass().getRecordComponents()) {
                try {
                    hash = mixHash(hash, hashString(component.getName()));
                    hash = mixHash(hash, hashValue(component.getGenericType(), component.getAccessor().invoke(record)));
                } catch (ReflectiveOperationException e) {
                    throw new IllegalStateException("Failed to hash record component '" + component.getName() + "'", e);
                }
            }
            return hash;
        }

        private static long hashObject(String typeName, String value) {
            long hash = HASH_SEED;
            hash = mixHash(hash, hashString(typeName));
            return mixHash(hash, hashString(value));
        }

        public void printFields() {
            fieldsFor(this.configuration).forEach(System.out::println);
        }

        public void printFields(T configuration) {
            fieldsFor(configuration).forEach(System.out::println);
        }

        public void printCategories() {
            categoriesFor(this.configuration).values().forEach(System.out::println);
        }

        public void printCategories(T configuration) {
            categoriesFor(configuration).values().forEach(System.out::println);
        }

        public T newConfigInstance() {
            try {
                return configClass.getDeclaredConstructor().newInstance();
            } catch (ReflectiveOperationException e) {
                throw new IllegalStateException("Failed to instantiate configuration", e);
            }
        }

        public T copyConfig() {
            return adapter.copy(this.configuration);
        }

        public T copyConfig(T source) {
            return adapter.copy(source);
        }

        public T copyInto(T source, T target) {
            Class<?> type = source.getClass();
            while (type != null) {
                for (java.lang.reflect.Field field : type.getDeclaredFields()) {
                    if (java.lang.reflect.Modifier.isStatic(field.getModifiers())) {
                        continue;
                    }
                    try {
                        field.setAccessible(true);
                        field.set(target, field.get(source));
                    } catch (IllegalAccessException e) {
                        throw new IllegalStateException("Failed to copy field '" + field.getName() + "'", e);
                    }
                }
                type = type.getSuperclass();
            }
            return target;
        }

        public ConfigManager<T, S> load() {
            this.adapter.load(this);
            return this;
        }

        public void save() {
            this.adapter.save(this);
            ConfigEvents.SAVE.invoker().onConfigSave();
        }

        public void saveDocument(Path file) {
            this.adapter.saveDocument(this.configuration, file);
        }

        public void saveDocument(T config, Path file) {
            this.adapter.saveDocument(config, file);
        }

        public T loadDocument(Path file) {
            return this.adapter.loadDocument(file, this.configClass);
        }

        public T loadDocument(InputStream stream) {
            return this.adapter.loadDocument(stream, this.configClass);
        }

        public boolean removeDocument(Path file) {
            return this.adapter.removeDocument(file);
        }

        // ---- 1.0.0 names --------------------------------------------------------------------------
        // Mods nest the library jar-in-jar and the loader keeps only the newest copy, so mods built
        // against 1.0.0 (preset methods) must keep working on 1.x.

        /** @deprecated since 1.1.0, use {@link #saveDocument(Path)}. */
        @Deprecated(since = "1.1.0")
        public void savePreset(Path file) {
            saveDocument(file);
        }

        /** @deprecated since 1.1.0, use {@link #saveDocument(Object, Path)}. */
        @Deprecated(since = "1.1.0")
        public void savePreset(T config, Path file) {
            saveDocument(config, file);
        }

        /** @deprecated since 1.1.0, use {@link #loadDocument(Path)}. */
        @Deprecated(since = "1.1.0")
        public T loadPreset(Path file) {
            return loadDocument(file);
        }

        /** @deprecated since 1.1.0, use {@link #loadDocument(InputStream)}. */
        @Deprecated(since = "1.1.0")
        public T loadPreset(InputStream stream) {
            return loadDocument(stream);
        }

        /** @deprecated since 1.1.0, use {@link #removeDocument(Path)}. */
        @Deprecated(since = "1.1.0")
        public boolean removePreset(Path file) {
            return removeDocument(file);
        }
    }
}
