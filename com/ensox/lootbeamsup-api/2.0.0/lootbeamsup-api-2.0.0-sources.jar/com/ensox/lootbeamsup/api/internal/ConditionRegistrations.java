package com.ensox.lootbeamsup.api.internal;

import com.ensox.lootbeamsup.api.ConditionGroup;
import com.ensox.lootbeamsup.api.EffectConditions;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.function.ToDoubleFunction;

/**
 * What addons registered through {@link com.ensox.lootbeamsup.api.LootBeamsApi#effectConditions()}, as an
 * immutable snapshot with a version.
 *
 * <p><b>Read side for LootBeamsUp only.</b> Addons use the public interfaces; the records here may change between
 * API versions.</p>
 */
public final class ConditionRegistrations {
    public enum Kind { ORDERED, NUMBER, FLAG }

    /**
     * A subgroup below a top-level group.
     *
     * @param key the subgroup's path from the top-level group, unique in it ({@code modifiers/blades})
     */
    public record Subgroup(String key, String id, String titleKey) { }

    /**
     * @param groups the subgroups that show the check, outermost first (empty: directly in the top-level group)
     * @param read   the addon's value function: stack in; a {@code String} (ordered), a {@code Double} (number)
     *               or a {@code Boolean} (flag) out
     */
    public record Check(String category, String id, String titleKey, List<Subgroup> groups, Kind kind,
                        List<String> values, Map<String, String> valueTitleKeys, double min, double max,
                        Function<Object, Object> read) {
        public Check {
            groups = List.copyOf(groups);
            values = List.copyOf(values);
            valueTitleKeys = Map.copyOf(valueTitleKeys);
        }

        /** The id saved in effect files: {@code "<category>:<check>"}, independent of subgroups. */
        public String type() {
            return category + ":" + id;
        }

        Check withValueTitles(Map<String, String> keys) {
            return new Check(category, id, titleKey, groups, kind, values, keys, min, max, read);
        }
    }

    /** A top-level group and every check under it, subgroups included, in registration order. */
    public record Category(String id, String titleKey, List<Check> checks) {
        public Category {
            checks = List.copyOf(checks);
        }
    }

    public static final EffectConditions API = (id, titleKey) -> top(id, titleKey);

    static final int MAX_VALUES = 256;
    private static final List<String> RESERVED = List.of("minecraft", "lootbeamsup");
    private static final Object LOCK = new Object();
    private record Top(String titleKey, Map<String, Subgroup> subgroups, Map<String, Check> checks) { }
    /** Guarded by LOCK. */
    private static final Map<String, Top> TOPS = new LinkedHashMap<>();
    private static volatile List<Category> snapshot = List.of();
    private static volatile long version;

    private ConditionRegistrations() { }

    /** Every registered top-level group with its checks, in registration order. */
    public static List<Category> snapshot() {
        return snapshot;
    }

    /** Grows with every registration, so readers can rebuild what they derived from {@link #snapshot()}. */
    public static long version() {
        return version;
    }

    private static ConditionGroup top(String id, String titleKey) {
        Ids.require(id, "Group");
        if (RESERVED.contains(id)) throw new IllegalArgumentException("Group id is reserved: " + id);
        Ids.requireKey(titleKey);
        synchronized (LOCK) {
            if (!TOPS.containsKey(id)) {
                TOPS.put(id, new Top(titleKey, new LinkedHashMap<>(), new LinkedHashMap<>()));
                publish();
            }
        }
        return new Handle(id, id, List.of());
    }

    /** Forgets every registration; for tests. */
    static void clear() {
        synchronized (LOCK) {
            TOPS.clear();
            publish();
        }
    }

    private static void add(Check check) {
        synchronized (LOCK) {
            Map<String, Check> checks = TOPS.get(check.category()).checks();
            if (checks.putIfAbsent(check.id(), check) != null)
                throw new IllegalArgumentException("Condition already registered: " + check.type());
            publish();
        }
    }

    private static void publish() {
        List<Category> next = new ArrayList<>();
        TOPS.forEach((id, top) -> next.add(new Category(id, top.titleKey(), List.copyOf(top.checks().values()))));
        snapshot = List.copyOf(next);
        version++;
    }

    /** @param top the top-level group; @param path this group's subgroups from it (empty for the top level) */
    private record Handle(String top, String id, List<Subgroup> path) implements ConditionGroup {
        private Handle {
            path = List.copyOf(path);
        }

        @Override
        public ConditionGroup group(String child, String titleKey) {
            Ids.require(child, "Group");
            Ids.requireKey(titleKey);
            String key = (path.isEmpty() ? "" : path.getLast().key() + "/") + child;
            List<Subgroup> childPath = new ArrayList<>(path);
            synchronized (LOCK) {
                Map<String, Subgroup> subgroups = TOPS.get(top).subgroups();
                Subgroup subgroup = subgroups.computeIfAbsent(key, ignored -> new Subgroup(key, child, titleKey));
                childPath.add(subgroup);
            }
            return new Handle(top, child, childPath);
        }

        @Override
        @SuppressWarnings("unchecked")
        public <S> ConditionGroup ordered(String check, String titleKey, List<String> values, Function<S, String> value) {
            Ids.require(check, "Condition");
            Ids.requireKey(titleKey);
            Objects.requireNonNull(value, "value");
            if (values == null || values.isEmpty() || values.size() > MAX_VALUES)
                throw new IllegalArgumentException("An ordered condition needs 1 to " + MAX_VALUES + " values");
            if (values.stream().distinct().count() != values.size())
                throw new IllegalArgumentException("Ordered values must be distinct: " + values);
            values.forEach(entry -> Ids.require(entry, "Value"));
            Function<Object, Object> read = stack -> value.apply((S) stack);
            add(new Check(top, check, titleKey, path, Kind.ORDERED, values, Map.of(), 0, values.size() - 1, read));
            return this;
        }

        @Override
        @SuppressWarnings("unchecked")
        public <S> ConditionGroup number(String check, String titleKey, double min, double max, ToDoubleFunction<S> value) {
            Ids.require(check, "Condition");
            Ids.requireKey(titleKey);
            Objects.requireNonNull(value, "value");
            if (!Double.isFinite(min) || !Double.isFinite(max) || min >= max)
                throw new IllegalArgumentException("Number bounds must be finite with min < max");
            Function<Object, Object> read = stack -> value.applyAsDouble((S) stack);
            add(new Check(top, check, titleKey, path, Kind.NUMBER, List.of(), Map.of(), min, max, read));
            return this;
        }

        @Override
        @SuppressWarnings("unchecked")
        public <S> ConditionGroup flag(String check, String titleKey, Predicate<S> value) {
            Ids.require(check, "Condition");
            Ids.requireKey(titleKey);
            Objects.requireNonNull(value, "value");
            Function<Object, Object> read = stack -> value.test((S) stack);
            add(new Check(top, check, titleKey, path, Kind.FLAG, List.of(), Map.of(), 0, 1, read));
            return this;
        }

        @Override
        public ConditionGroup valueTitles(String check, Function<String, String> titleKey) {
            Objects.requireNonNull(titleKey, "titleKey");
            synchronized (LOCK) {
                Map<String, Check> checks = TOPS.get(top).checks();
                Check existing = checks.get(check);
                if (existing == null || existing.kind() != Kind.ORDERED || !existing.groups().equals(path))
                    throw new IllegalArgumentException("No ordered condition " + check + " in group " + id);
                Map<String, String> keys = new LinkedHashMap<>();
                for (String value : existing.values()) {
                    String key = titleKey.apply(value);
                    Ids.requireKey(key);
                    keys.put(value, key);
                }
                checks.put(check, existing.withValueTitles(keys));
                publish();
            }
            return this;
        }
    }
}
