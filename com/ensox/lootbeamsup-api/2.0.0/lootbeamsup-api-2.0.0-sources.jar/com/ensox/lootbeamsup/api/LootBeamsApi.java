package com.ensox.lootbeamsup.api;

import com.ensox.lootbeamsup.api.internal.ConditionRegistrations;
import com.ensox.lootbeamsup.api.internal.ItemColorRegistrations;

/**
 * Entry point for mods that integrate with LootBeamsUp, split by area:
 * <ul>
 *     <li>{@link #effectConditions()}: your own checks in the effect editor's Targets and Conditions;</li>
 *     <li>{@link #itemColors()}: the beam color of your items.</li>
 * </ul>
 *
 * <p>The API uses only JDK types, so one artifact ({@code com.ensox:lootbeamsup-api}) serves every loader and
 * Minecraft version, and a mod can call it through reflection without depending on LootBeamsUp at all (look the
 * methods up on the public interfaces). Call it from your client initialisation, on any loader and in any order
 * relative to LootBeamsUp: registrations are kept here and LootBeamsUp picks them up whenever they arrive.</p>
 *
 * <pre>
 * var smithery = LootBeamsApi.effectConditions().group("smithery", "smithery.lootbeams.category");
 * smithery.ordered("rarity", "smithery.lootbeams.rarity", List.of("crude", "fine", "masterwork"),
 *     (ItemStack stack) -&gt; SmitheryData.rarity(stack));
 * smithery.group("modifiers", "smithery.lootbeams.modifiers")
 *     .number("sharpness", "smithery.modifier.sharpness", 0, 5, (ItemStack stack) -&gt; SmitheryData.sharpness(stack));
 *
 * LootBeamsApi.itemColors().register("smithery", (ItemStack stack) -&gt; SmitheryData.rarityColor(stack));
 * </pre>
 *
 * <p>Do not bundle this API into your jar: compile against it ({@code compileOnly}) and let LootBeamsUp
 * provide the classes at runtime.</p>
 */
public final class LootBeamsApi {
    /** Raised when the API gains features; check it before calling methods newer than your minimum. */
    public static final int VERSION = 2;

    private LootBeamsApi() { }

    /** Checks for the effect editor's Targets and Conditions, grouped into your own menu categories. */
    public static EffectConditions effectConditions() {
        return ConditionRegistrations.API;
    }

    /** Colors for your items' beams (and everything else that inherits the beam color). */
    public static ItemColors itemColors() {
        return ItemColorRegistrations.API;
    }
}
