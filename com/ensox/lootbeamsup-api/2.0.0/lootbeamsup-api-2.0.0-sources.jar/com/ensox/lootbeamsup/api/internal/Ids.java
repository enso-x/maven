package com.ensox.lootbeamsup.api.internal;

import java.util.regex.Pattern;

/** Validation shared by the API's registries. */
final class Ids {
    private static final Pattern ID = Pattern.compile("[a-z0-9_.-]{1,64}");

    private Ids() { }

    static void require(String id, String what) {
        if (id == null || !ID.matcher(id).matches())
            throw new IllegalArgumentException(what + " id must match [a-z0-9_.-]{1,64}: " + id);
    }

    static void requireKey(String key) {
        if (key == null || key.isBlank() || key.length() > 256) throw new IllegalArgumentException("Invalid translation key: " + key);
    }
}
