package com.ensox.lootbeamsup.api.internal;

import com.ensox.lootbeamsup.api.ItemColors;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.function.Function;

/**
 * What addons registered through {@link com.ensox.lootbeamsup.api.LootBeamsApi#itemColors()}.
 *
 * <p><b>Read side for LootBeamsUp only.</b></p>
 */
public final class ItemColorRegistrations {
    /** @param color stack in; an {@code Integer} 0xRRGGBB or {@code null} out */
    public record Provider(String id, Function<Object, Object> color) { }

    public static final ItemColors API = new ItemColors() {
        @Override
        @SuppressWarnings("unchecked")
        public <S> ItemColors register(String id, Function<S, Integer> color) {
            Ids.require(id, "Color provider");
            Objects.requireNonNull(color, "color");
            synchronized (LOCK) {
                if (providers.stream().anyMatch(provider -> provider.id().equals(id)))
                    throw new IllegalArgumentException("Color provider already registered: " + id);
                List<Provider> next = new ArrayList<>(providers);
                next.add(new Provider(id, stack -> color.apply((S) stack)));
                providers = List.copyOf(next);
            }
            return this;
        }
    };

    private static final Object LOCK = new Object();
    private static volatile List<Provider> providers = List.of();

    private ItemColorRegistrations() { }

    /** Providers in registration order. */
    public static List<Provider> providers() {
        return providers;
    }

    /** Forgets every provider; for tests. */
    static void clear() {
        synchronized (LOCK) {
            providers = List.of();
        }
    }
}
