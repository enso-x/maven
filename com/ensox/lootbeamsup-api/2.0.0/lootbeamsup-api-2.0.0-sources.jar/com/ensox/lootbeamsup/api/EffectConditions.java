package com.ensox.lootbeamsup.api;

/**
 * Addon checks for the effect editor's Targets and Conditions. Each mod gets a top-level group in the Type menu
 * (after the built-in Item / Data / World / Block, under a rule); groups can hold subgroups, shown as submenus.
 */
public interface EffectConditions {
    /**
     * The top-level group {@code id}, created on first use. Its checks are saved in effect files as
     * {@code "<id>:<check>"}, whatever subgroup shows them, so moving a check between subgroups keeps saved effects.
     *
     * @param id       lower-case id, usually your mod id ({@code [a-z0-9_.-]{1,64}}; {@code minecraft} and
     *                 {@code lootbeamsup} are reserved)
     * @param titleKey translation key of the group's title in your mod's language files
     * @return the group; calling again with the same id returns the same group
     */
    ConditionGroup group(String id, String titleKey);
}
