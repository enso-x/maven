package com.ensox.lootbeamsup.api;

import java.util.function.Function;

/**
 * Beam colors for your items. LootBeamsUp asks providers after the player's own choices (a fixed beam color,
 * color overrides, a color stored on the item) and before the item's name and rarity colors; players can turn
 * mod colors off in the beam settings ("Use Mod Color").
 */
public interface ItemColors {
    /**
     * Adds a color provider. Providers are asked in registration order; the first color wins.
     *
     * @param id    lower-case id, usually your mod id ({@code [a-z0-9_.-]{1,64}}); registering it twice throws
     * @param color the stack's color as {@code 0xRRGGBB}, or {@code null} for no opinion (other providers, then
     *              the name and rarity colors, decide). Runs on the client thread and may run every frame: keep it
     *              cheap and dependent on the stack only. A provider that throws is treated as {@code null}.
     */
    <S> ItemColors register(String id, Function<S, Integer> color);
}
