package com.ensox.lootbeamsup.api;

import java.util.function.Function;

/**
 * Your mod's own rarities, for mods whose rarities go beyond vanilla's four (which top out at Epic). A rarity is a
 * name and a color, and LootBeamsUp treats it as the item's rarity:
 * <ul>
 *     <li>the name shows on the rarity line of nametags and tooltips instead of the vanilla rarity (an item group
 *     label the player made still comes first), in the rarity's color;</li>
 *     <li>the color replaces the vanilla rarity color where the beam takes its color from the rarity (after the
 *     player's color settings, mod item colors and the name color).</li>
 * </ul>
 */
public interface Rarities {
    /**
     * Adds a rarity provider. Providers are asked in registration order; the first one that gives the stack a label
     * decides both its name and its color.
     *
     * <p>Both functions run on the client thread and may run every frame: keep them cheap. A function that throws
     * counts as {@code null}.</p>
     *
     * @param id    lower-case id, usually your mod id ({@code [a-z0-9_.-]{1,64}}); registering it twice throws
     * @param label the stack's rarity name as a translation key (shown translated when the language has it, as text
     *              otherwise), or {@code null} when the stack has none of your rarities (the vanilla rarity stays)
     * @param color the rarity's color as {@code 0xRRGGBB}, or {@code null} for the beam color; asked only when
     *              {@code label} gave a name
     */
    <S> Rarities register(String id, Function<S, String> label, Function<S, Integer> color);
}
