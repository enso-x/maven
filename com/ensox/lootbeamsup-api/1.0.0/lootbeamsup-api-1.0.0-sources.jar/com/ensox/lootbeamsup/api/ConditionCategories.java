package com.ensox.lootbeamsup.api;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.function.ToDoubleFunction;
import java.util.regex.Pattern;

/**
 * Registry behind {@link LootBeamsApi}: what addons registered, as an immutable snapshot with a version.
 *
 * <p><b>Read side for LootBeamsUp only.</b> Addons use {@link LootBeamsApi}; the records here may change
 * between API versions.</p>
 */
public final class ConditionCategories {
    public enum Kind { ORDERED, NUMBER, FLAG }

    /**
     * @param read the addon's value function: stack in; a {@code String} (ordered), a {@code Double} (number)
     *             or a {@code Boolean} (flag) out
     */
    public record Check(String category, String id, String titleKey, Kind kind, List<String> values,
                        Map<String, String> valueTitleKeys, double min, double max, Function<Object, Object> read) {
        public Check {
            values = List.copyOf(values);
            valueTitleKeys = Map.copyOf(valueTitleKeys);
        }

        /** The id saved in effect files: {@code "<category>:<check>"}. */
        public String type() {
            return category + ":" + id;
        }
    }

    public record Category(String id, String titleKey, List<Check> checks) {
        public Category {
            checks = List.copyOf(checks);
        }
    }

    static final int MAX_VALUES = 256;
    private static final Pattern ID = Pattern.compile("[a-z0-9_.-]{1,64}");
    private static final List<String> RESERVED = List.of("minecraft", "lootbeamsup");
    private static final Object LOCK = new Object();
    /** Category id -> its checks by id, in registration order. Guarded by LOCK. */
    private static final Map<String, Map<String, Check>> CHECKS = new LinkedHashMap<>();
    private static final Map<String, String> TITLES = new LinkedHashMap<>();
    private static volatile List<Category> snapshot = List.of();
    private static volatile long version;

    private ConditionCategories() { }

    /** Every registered category with its checks, in registration order. */
    public static List<Category> snapshot() {
        return snapshot;
    }

    /** Grows with every registration, so readers can rebuild what they derived from {@link #snapshot()}. */
    public static long version() {
        return version;
    }

    static ConditionCategory category(String id, String titleKey) {
        requireId(id, "Category");
        if (RESERVED.contains(id)) throw new IllegalArgumentException("Category id is reserved: " + id);
        requireKey(titleKey);
        synchronized (LOCK) {
            if (!CHECKS.containsKey(id)) {
                CHECKS.put(id, new LinkedHashMap<>());
                TITLES.put(id, titleKey);
                publish();
            }
        }
        return new Handle(id);
    }

    /** Forgets every registration; for tests. */
    static void clear() {
        synchronized (LOCK) {
            CHECKS.clear();
            TITLES.clear();
            publish();
        }
    }

    private static void add(Check check) {
        synchronized (LOCK) {
            Map<String, Check> checks = CHECKS.get(check.category());
            if (checks.putIfAbsent(check.id(), check) != null)
                throw new IllegalArgumentException("Condition already registered: " + check.type());
            publish();
        }
    }

    private static void publish() {
        List<Category> next = new ArrayList<>();
        CHECKS.forEach((id, checks) -> next.add(new Category(id, TITLES.get(id), List.copyOf(checks.values()))));
        snapshot = List.copyOf(next);
        version++;
    }

    private static void requireId(String id, String what) {
        if (id == null || !ID.matcher(id).matches())
            throw new IllegalArgumentException(what + " id must match [a-z0-9_.-]{1,64}: " + id);
    }

    private static void requireKey(String key) {
        if (key == null || key.isBlank() || key.length() > 256) throw new IllegalArgumentException("Invalid translation key: " + key);
    }

    private record Handle(String id) implements ConditionCategory {
        @Override
        @SuppressWarnings("unchecked")
        public <S> ConditionCategory ordered(String check, String titleKey, List<String> values, Function<S, String> value) {
            requireId(check, "Condition");
            requireKey(titleKey);
            Objects.requireNonNull(value, "value");
            if (values == null || values.isEmpty() || values.size() > MAX_VALUES)
                throw new IllegalArgumentException("An ordered condition needs 1 to " + MAX_VALUES + " values");
            if (values.stream().distinct().count() != values.size())
                throw new IllegalArgumentException("Ordered values must be distinct: " + values);
            values.forEach(entry -> requireId(entry, "Value"));
            Function<Object, Object> read = stack -> value.apply((S) stack);
            add(new Check(id, check, titleKey, Kind.ORDERED, values, Map.of(), 0, values.size() - 1, read));
            return this;
        }

        @Override
        @SuppressWarnings("unchecked")
        public <S> ConditionCategory number(String check, String titleKey, double min, double max, ToDoubleFunction<S> value) {
            requireId(check, "Condition");
            requireKey(titleKey);
            Objects.requireNonNull(value, "value");
            if (!Double.isFinite(min) || !Double.isFinite(max) || min >= max)
                throw new IllegalArgumentException("Number bounds must be finite with min < max");
            Function<Object, Object> read = stack -> value.applyAsDouble((S) stack);
            add(new Check(id, check, titleKey, Kind.NUMBER, List.of(), Map.of(), min, max, read));
            return this;
        }

        @Override
        @SuppressWarnings("unchecked")
        public <S> ConditionCategory flag(String check, String titleKey, Predicate<S> value) {
            requireId(check, "Condition");
            requireKey(titleKey);
            Objects.requireNonNull(value, "value");
            Function<Object, Object> read = stack -> value.test((S) stack);
            add(new Check(id, check, titleKey, Kind.FLAG, List.of(), Map.of(), 0, 1, read));
            return this;
        }

        @Override
        public ConditionCategory valueTitles(String check, Function<String, String> titleKey) {
            Objects.requireNonNull(titleKey, "titleKey");
            synchronized (LOCK) {
                Map<String, Check> checks = CHECKS.get(id);
                Check existing = checks.get(check);
                if (existing == null || existing.kind() != Kind.ORDERED)
                    throw new IllegalArgumentException("No ordered condition " + id + ":" + check);
                Map<String, String> keys = new LinkedHashMap<>();
                for (String value : existing.values()) {
                    String key = titleKey.apply(value);
                    requireKey(key);
                    keys.put(value, key);
                }
                checks.put(check, new Check(id, check, existing.titleKey(), Kind.ORDERED, existing.values(), keys,
                    existing.min(), existing.max(), existing.read()));
                publish();
            }
            return this;
        }
    }
}
