package com.ensox.lootbeamsup.api.internal;

import com.ensox.lootbeamsup.api.Rarities;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.function.Function;

/**
 * What addons registered through {@link com.ensox.lootbeamsup.api.LootBeamsApi#rarities()}.
 *
 * <p><b>Read side for LootBeamsUp only.</b></p>
 */
public final class RarityRegistrations {
    /**
     * @param label stack in; a {@code String} translation key or text, or {@code null} out
     * @param color stack in; an {@code Integer} 0xRRGGBB, or {@code null} out
     */
    public record Provider(String id, Function<Object, Object> label, Function<Object, Object> color) { }

    public static final Rarities API = new Rarities() {
        @Override
        @SuppressWarnings("unchecked")
        public <S> Rarities register(String id, Function<S, String> label, Function<S, Integer> color) {
            Objects.requireNonNull(color, "color");
            add(id, label, stack -> color.apply((S) stack));
            return this;
        }
    };

    private static final Object LOCK = new Object();
    private static volatile List<Provider> providers = List.of();

    private RarityRegistrations() { }

    @SuppressWarnings("unchecked")
    private static <S> void add(String id, Function<S, String> label, Function<Object, Object> color) {
        Ids.require(id, "Rarity provider");
        Objects.requireNonNull(label, "label");
        synchronized (LOCK) {
            if (providers.stream().anyMatch(provider -> provider.id().equals(id)))
                throw new IllegalArgumentException("Rarity provider already registered: " + id);
            List<Provider> next = new ArrayList<>(providers);
            next.add(new Provider(id, stack -> label.apply((S) stack), color));
            providers = List.copyOf(next);
        }
    }

    /** Providers in registration order. */
    public static List<Provider> providers() {
        return providers;
    }

    /** Forgets every provider; for tests. */
    static void clear() {
        synchronized (LOCK) {
            providers = List.of();
        }
    }
}
