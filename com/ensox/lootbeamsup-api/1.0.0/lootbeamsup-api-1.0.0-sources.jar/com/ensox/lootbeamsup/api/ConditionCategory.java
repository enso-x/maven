package com.ensox.lootbeamsup.api;

import java.util.List;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.function.ToDoubleFunction;

/**
 * One addon category of effect conditions. Each check reads a value from an item stack; LootBeamsUp supplies the
 * editor fields, the comparison operators and their validation.
 *
 * <p>The stack type parameter {@code S} is the game's {@code ItemStack}: name it in the lambda,
 * {@code (ItemStack stack) -> ...}. The API itself does not mention Minecraft types, so it is the same on every
 * loader and mapping.</p>
 *
 * <p>Value functions run on the client thread, once per item per evaluation pass at most. Keep them cheap and
 * dependent on the stack only (its components). A function that throws makes the check "unknown", which never
 * matches, even under NOT.</p>
 */
public interface ConditionCategory {
    /** The category id given to {@link LootBeamsApi#category}. */
    String id();

    /**
     * A check over an ordered set of named values (a rarity, a tier). The editor offers equal, not equal, below,
     * at most, above and at least; order is the order of {@code values}. A value the function returns that is not
     * in {@code values} matches nothing.
     *
     * @param values ids of the values, lowest first (1 to 256 of them)
     */
    <S> ConditionCategory ordered(String id, String titleKey, List<String> values, Function<S, String> value);

    /** A numeric check (a level, a count); the editor accepts thresholds from {@code min} to {@code max}. */
    <S> ConditionCategory number(String id, String titleKey, double min, double max, ToDoubleFunction<S> value);

    /** A yes/no check (signed, broken, blessed). */
    <S> ConditionCategory flag(String id, String titleKey, Predicate<S> value);

    /**
     * Translation keys for the values of the ordered check {@code id}, shown in the editor instead of the raw ids.
     *
     * @param titleKey maps a value id to its translation key
     */
    ConditionCategory valueTitles(String id, Function<String, String> titleKey);
}
