package com.ensox.lootbeamsup.api;

/**
 * Entry point for mods that integrate with LootBeamsUp.
 *
 * <p>The API uses only JDK types, so one artifact ({@code com.ensox:lootbeamsup-api}) serves every loader and
 * Minecraft version, and a mod can call it through reflection without depending on LootBeamsUp at all.
 * Call it from your client initialisation, on any loader and in any order relative to LootBeamsUp:
 * registrations are kept here and LootBeamsUp picks them up whenever they arrive.</p>
 *
 * <pre>
 * LootBeamsApi.category("smithery", "smithery.lootbeams.category")
 *     .ordered("rarity", "smithery.lootbeams.rarity", List.of("crude", "fine", "masterwork"),
 *              (ItemStack stack) -&gt; SmitheryData.rarity(stack))
 *     .number("sharpening", "smithery.lootbeams.sharpening", 0, 15,
 *              (ItemStack stack) -&gt; SmitheryData.sharpening(stack));
 * </pre>
 *
 * <p>Do not bundle this API into your jar: compile against it ({@code compileOnly}) and let LootBeamsUp
 * provide the classes at runtime.</p>
 */
public final class LootBeamsApi {
    /** Raised when the API gains features; check it before calling methods newer than version 1. */
    public static final int VERSION = 1;

    private LootBeamsApi() { }

    /**
     * The condition category {@code id}, created on first use. Its checks appear in the effect editor's Type menu
     * (Conditions and Targets) under the category's title, and are saved as {@code "<category>:<check>"}.
     *
     * @param id       lower-case id, usually your mod id ({@code [a-z0-9_.-]+}; {@code minecraft} and
     *                 {@code lootbeamsup} are reserved)
     * @param titleKey translation key of the category's title in your mod's language files
     * @return the category; calling again with the same id returns the same category
     */
    public static ConditionCategory category(String id, String titleKey) {
        return ConditionCategories.category(id, titleKey);
    }
}
