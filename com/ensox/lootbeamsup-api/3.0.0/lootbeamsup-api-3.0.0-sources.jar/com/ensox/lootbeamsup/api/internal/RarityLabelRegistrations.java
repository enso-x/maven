package com.ensox.lootbeamsup.api.internal;

import com.ensox.lootbeamsup.api.RarityLabels;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.function.Function;

/**
 * What addons registered through {@link com.ensox.lootbeamsup.api.LootBeamsApi#rarityLabels()}.
 *
 * <p><b>Read side for LootBeamsUp only.</b></p>
 */
public final class RarityLabelRegistrations {
    /** @param label stack in; a {@code String} translation key or text, or {@code null} out */
    public record Provider(String id, Function<Object, Object> label) { }

    public static final RarityLabels API = new RarityLabels() {
        @Override
        @SuppressWarnings("unchecked")
        public <S> RarityLabels register(String id, Function<S, String> label) {
            Ids.require(id, "Rarity label provider");
            Objects.requireNonNull(label, "label");
            synchronized (LOCK) {
                if (providers.stream().anyMatch(provider -> provider.id().equals(id)))
                    throw new IllegalArgumentException("Rarity label provider already registered: " + id);
                List<Provider> next = new ArrayList<>(providers);
                next.add(new Provider(id, stack -> label.apply((S) stack)));
                providers = List.copyOf(next);
            }
            return this;
        }
    };

    private static final Object LOCK = new Object();
    private static volatile List<Provider> providers = List.of();

    private RarityLabelRegistrations() { }

    /** Providers in registration order. */
    public static List<Provider> providers() {
        return providers;
    }

    /** Forgets every provider; for tests. */
    static void clear() {
        synchronized (LOCK) {
            providers = List.of();
        }
    }
}
