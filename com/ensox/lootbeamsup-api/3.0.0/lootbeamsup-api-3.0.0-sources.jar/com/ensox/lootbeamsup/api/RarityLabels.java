package com.ensox.lootbeamsup.api;

import java.util.function.Function;

/**
 * Rarity names for your items, for mods with their own rarities beyond vanilla's four. LootBeamsUp shows the label
 * on the rarity line of nametags and tooltips: after an item group label the player made, before the vanilla
 * rarity (which tops out at Epic).
 */
public interface RarityLabels {
    /**
     * Adds a label provider. Providers are asked in registration order; the first label wins.
     *
     * @param id    lower-case id, usually your mod id ({@code [a-z0-9_.-]{1,64}}); registering it twice throws
     * @param label the stack's rarity as a translation key (shown translated when the language has it, as text
     *              otherwise), or {@code null} for no opinion (the vanilla rarity shows). Runs on the client thread
     *              and may run every frame: keep it cheap. A provider that throws is treated as {@code null}.
     */
    <S> RarityLabels register(String id, Function<S, String> label);
}
